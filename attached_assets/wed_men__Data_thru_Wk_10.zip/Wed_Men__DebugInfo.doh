=========== Information for Tech Support ===========
Please: Ignore this page unless you are asked for it!
If you don't understand it, that is perfectly OK.
=========== Details for Tech Support ===========

11/6/2024  5:35 pm

Filename: wed_men
Location: c:\users\public\documents\bls2025\leagues\
Created: 8/15/2004 5:20 pm
Restarted on: 8/27/2024 9:20 pm
File GUID: {27436CAE-532A-418D-9ED6-C9F27336363F}
Structures: Now 3127, Created 1302, Hi/Low 3127/1302
Program Version: Now 37.03.03  Created 17.03-a
                 Hi/Low 37.03.03/17.03-a
Datafile Owner: DOUGLAS  MOYE  
Datafile Serial Number: 42413
Current Num. Teams (Num_Teams): 16
Max Num. Teams Used (Max_Num_Teams): 16
Highest Physical Team Record (max_phys_team): 16
Next Bowler Record (bnext): 238
Week 10   Highest Week: 11
USBC tracking ID number: {00000000-0000-0000-0000-000000000000}

App Data Directory: C:\Users\Public\Documents\bls2025\Leagues\

Printers installed: Yes
    Default Printer: 4 ===> Brother HL-L6200DW series
    Printer #0: OneNote for Windows 10
    Printer #1: Microsoft XPS Document Writer
    Printer #2: Microsoft Print to PDF
    Printer #3: Fax
    Printer #4: Brother HL-L6200DW series

Elevation Level: 

Machine ID: 0000000000000000000000000000000000000000
Program Owner: Michael Shearer  Perfect Game
Program Serial Number: 365879

Screen Width: 1600
Screen Height: 900
Screen Pixels Per inch: 96
Screen Ratio: 1.00

Screen Working area Top: 0
Screen Working area Left: 0
Screen Working area Height: 852
Screen Working area Width: 1600

Screen DeskTop area Top: 0
Screen DeskTop area Left: 0
Screen DeskTop area Height: 900
Screen DeskTop area Width: 1600

Monitors Count: 1
Monitor 0 - 720, 1024, 28, 284

0/0- NN  Team 0
1/1- YY  ONLY PINS
2/2- YY  MARK'S PRO SHOP
3/3- YY  BEER NUTS
4/4- YY  KING PIN PRO SHO
5/5- YY  PROJECT X
6/6- YY  LIGMA BOWLS
7/7- YY  NO LIMIT SOLDIERS
8/8- YY  POCKET POUNDERS
9/9- YY  420 FRIENDLY
10/10- YY  RED DOTS
11/11- YY  HITMEN
12/12- YY  OLD BALLS
13/13- YY  2 BALLS 1 PIN
14/14- YY  DOUBLE OT
15/15- YY  PERFECT GAME
16/16- YY  LAST CALL
