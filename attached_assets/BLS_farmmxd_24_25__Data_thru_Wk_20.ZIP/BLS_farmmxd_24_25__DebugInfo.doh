=========== Information for Tech Support ===========
Please: Ignore this page unless you are asked for it!
If you don't understand it, that is perfectly OK.
=========== Details for Tech Support ===========

2/4/2025  4:32 pm

Filename: bls_farmmxd_24_25
Location: c:\users\public\documents\bls2025\leagues\
Created: 9/8/2008 6:19 pm
Restarted on: 9/9/2024 3:50 pm
File GUID: {BBDED725-7706-47CD-ABEC-84E64CB30459}
Structures: Now 3127, Created 2001, Hi/Low 3127/2001
Program Version: Now 37.04.02  Created 20.25.08
                 Hi/Low 37.04.02/20.02.03
Datafile Owner: Jery Harris  Drakeshire Lanes
Datafile Serial Number: 123985
Current Num. Teams (Num_Teams): 16
Max Num. Teams Used (Max_Num_Teams): 16
Highest Physical Team Record (max_phys_team): 20
Next Bowler Record (bnext): 267
Week 20   Highest Week: 20
USBC tracking ID number: {00000000-0000-0000-0000-000000000000}

App Data Directory: C:\Users\Public\Documents\bls2025\Leagues\

Printers installed: Yes
    Default Printer: 4 ===> Brother HL-L6200DW series
    Printer #0: OneNote for Windows 10
    Printer #1: Microsoft XPS Document Writer
    Printer #2: Microsoft Print to PDF
    Printer #3: Fax
    Printer #4: Brother HL-L6200DW series

Elevation Level: 

Machine ID: 0000000000000000000000000000000000000000
Program Owner: Michael Shearer  Perfect Game
Program Serial Number: 365879

Screen Width: 1600
Screen Height: 900
Screen Pixels Per inch: 96
Screen Ratio: 1.00

Screen Working area Top: 0
Screen Working area Left: 0
Screen Working area Height: 852
Screen Working area Width: 1600

Screen DeskTop area Top: 0
Screen DeskTop area Left: 0
Screen DeskTop area Height: 900
Screen DeskTop area Width: 1600

Monitors Count: 1
Monitor 0 - 720, 1024, 91, 288

0/0- NN  Team 0
1/1- YY  Carbliss Crew
2/2- YY  Just Us
3/14- YY  Shot Queens
4/4- YY  Spare Parts
5/13- YY  Fire in the Hole
6/6- YY  Four Stars
7/7- YY  Hambone
8/8- YY  Lucky Strikes
9/9- YY  Split Happens
10/10- YY  Gutter Balls
11/11- YY  Airtight
12/12- YY  Ruff Riders
13/16- YY  Doctor Funk
14/17- YY  Slow Rollers
15/19- YY  Glory Bowl
16/20- YY  Aspareigus?
17/0- YY  Team 15
18/0- YY  Team 18
19/0- NN  Empty Team
20/0- NN  Empty Team
